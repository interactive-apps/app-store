/* global angular */

'use strict';

/* Services */

var indicatorsServices = angular.module('indicatorsServices', [ 'mainServices' ]);
