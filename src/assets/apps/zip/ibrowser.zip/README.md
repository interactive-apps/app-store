 indicatorBrowserApp

