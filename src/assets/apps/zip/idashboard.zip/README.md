Interactive Dashboard App
===============================

DHIS 2 Platform based HTML App for interactive Dashboard analysis.

The Application is powered by AngularJS, HTML5 and CSS3

Authors
1. John Francis Mukulu <john.f.mukulu@gmail.com>
2. Kelvin Kulwa Mbwilo <kelvinmbwilo@gmail.com>
3. Leonard Constantine Mpande <leo.august27@gmail.com>
4. Tuzo Mahane Engelbert <tuzoengelbert@gmail.com>
