import { Injectable } from '@angular/core';
import {Effect, Actions} from "@ngrx/effects";
import {Observable} from "rxjs";
import {Action} from "@ngrx/store";
import {
  LOAD_REPOSITORIES_ACTION, ErrorOccurredAction, RepositoriesLoadedAction,
  RepositoriesUpdatedAction, UPDATE_REPOSITORIES_ACTION, REPOSITORIES_LOADED_ACTION, LoadMetadataPackagesAction
} from "../actions";
import {RepositoriesService} from "../../shared/providers/repositories.service";

@Injectable()
export class RepositoriesEffectService {

  constructor(
    private actions$: Actions,
    private repositoriesService: RepositoriesService
  ) { }

  @Effect() repositories$: Observable<Action> = this.actions$
    .ofType(LOAD_REPOSITORIES_ACTION)
    .switchMap(action => this.repositoriesService.loadRepositories())
    .map(repositories => new RepositoriesLoadedAction(repositories))
    .catch((error) => Observable.of(new ErrorOccurredAction(error)));

  @Effect() repositoriesLoaded$: Observable<Action> = this.actions$
    .ofType(REPOSITORIES_LOADED_ACTION)
    .switchMap(action => this.repositoriesService.getUrlArray(action.payload))
    .map(repositories => new LoadMetadataPackagesAction(repositories))
    .catch((error) => Observable.of(new ErrorOccurredAction(error)));

  @Effect() updatedRepositories$: Observable<Action> = this.actions$
    .ofType(UPDATE_REPOSITORIES_ACTION)
    .switchMap(action => this.repositoriesService.updateRepositories(action.payload))
    .map(repositories => new RepositoriesUpdatedAction(repositories))
    .catch(() => Observable.of(new ErrorOccurredAction('Error occured while updating repositories')));

}
