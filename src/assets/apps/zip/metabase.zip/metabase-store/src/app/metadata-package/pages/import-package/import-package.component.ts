import { Component, OnInit } from '@angular/core';
import {ApplicationState} from "../../../store/application-state";
import {Store} from "@ngrx/store";
import {ActivatedRoute} from "@angular/router";
import {currentMetadataSelector} from "../../../store/selectors/current-metadata.selector";
import {currentMetadataPackageSelector} from "../../../store/selectors/current-metadata-package.selector";
import {LoadMetadataAction, CurrentMetadataPackageChangeAction} from "../../../store/actions";
import * as _ from 'lodash';
import {MetadataService} from "../../providers/metadata.service";

@Component({
  selector: 'app-import-package',
  templateUrl: './import-package.component.html',
  styleUrls: ['./import-package.component.css']
})
export class ImportPackageComponent implements OnInit {

  constructor(
    private store: Store<ApplicationState>,
    private route: ActivatedRoute,
    private metadataService: MetadataService
  ) { }

  ngOnInit() {
    this.route.parent.params.subscribe(params => {
      this.store.dispatch(new CurrentMetadataPackageChangeAction({id: params['id'], version: params['version']}));
      console.log('loading metadata details');
      this.store.select(currentMetadataPackageSelector).subscribe(metadataPackage => {
        if(metadataPackage) {
          const currentMetadataPackageVersion: any = _.find(metadataPackage.versions, ['version', params['version']]);
          if(currentMetadataPackageVersion) {
            if(!currentMetadataPackageVersion.hasOwnProperty('metadata') && currentMetadataPackageVersion.hasOwnProperty('href')) {
              const metadataDetails: any = {
                packageId: metadataPackage.id,
                packageVersion: params['version'],
                metadataUrl: currentMetadataPackageVersion.href
              };
              this.store.dispatch(new LoadMetadataAction(metadataDetails));
            }
          }
        }
      });

      this.store.select(currentMetadataSelector).subscribe(metadataDetails => {
        if(metadataDetails.metadataDetails) {
          console.log('Metadata Details loaded');
          metadataDetails.metadataItems.forEach((metadataItemType:any) => {
            metadataDetails.metadataDetails[metadataItemType].forEach(metadata => {
              console.log('Analyzing dependencies for',metadata.name)
              const dependencies = this.metadataService.getDependencies(metadata, metadataItemType)
              console.log('Found ' + dependencies.length + ' dependencies')
              console.log('Checking dependencies availability');
              console.log(this.metadataService.checkDependenciesAvailability(metadataDetails.metadataDetails, dependencies))

            })
          });
        }
      })
    })

  }

}
