import {Component, OnInit, Input, ChangeDetectionStrategy, Output, EventEmitter} from '@angular/core';
import * as _ from 'lodash';
@Component({
  selector: 'app-repositories-section',
  templateUrl: './repositories-section.component.html',
  styleUrls: ['./repositories-section.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RepositoriesSectionComponent implements OnInit {

  @Input() repositories: any;

  @Output() onRepositoriesUpdate: EventEmitter<any> = new EventEmitter<any>();
  @Output() onClose: EventEmitter<boolean> = new EventEmitter<boolean>();
  constructor() { }

  ngOnInit() {
  }

  updateRepository(updatedRepository) {
    const repositoryIndex = _.findIndex(this.repositories, ['id', updatedRepository.id]);
    const repositories = _.clone(this.repositories);
    repositories[repositoryIndex] = updatedRepository;
    this.onRepositoriesUpdate.emit(repositories);
  }

  toggleRepositorySelection(updatedDepository) {
    const repository: any = _.clone(updatedDepository);
    repository.selected = !repository.selected;
    this.updateRepository(repository);
  }

  close() {
    this.onClose.emit(true)
  }

}
