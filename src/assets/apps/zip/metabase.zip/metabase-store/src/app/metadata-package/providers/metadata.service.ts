import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import {IndicatorService} from "./indicator.service";
import {IndicatorTypeService} from "./indicator-type.service";
@Injectable()
export class MetadataService {

  constructor(
    private indicatorService: IndicatorService,
    private indicatorTypeService: IndicatorTypeService
  ) { }

  getDependencies(currentMetadata, metadataType) {
    switch (metadataType) {
      case 'indicators': {
        return this.indicatorService.getDependencies(currentMetadata.originalVersion);
      }

      default:
        return [];
    }
  }

  checkDependenciesAvailability(metadataObject, dependencies) {
    if(dependencies.length > 0) {
      dependencies.forEach(dependency => {
        console.log(dependency)
      })
    }
  }

  checkFromSystem(metadataType, metadata) {
    switch (metadataType) {
      case 'indicatorType': {

      }
    }
  }

}
