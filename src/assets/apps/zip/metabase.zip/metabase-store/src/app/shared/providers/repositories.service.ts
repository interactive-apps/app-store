import { Injectable } from '@angular/core';
import {HttpClientService} from "./http-client.service";
import {Observable} from "rxjs";
import {Response} from "@angular/http";

@Injectable()
export class RepositoriesService {

  defaultRepository: any;
  datastoreUrl: string;
  constructor(private http: HttpClientService) {
    this.defaultRepository = {
      id: 1,
      name: 'HISP Tanzania Repository',
      url: 'https://raw.githubusercontent.com/hisptz/dhis2-metadata-repo/master/packages.json',
      selected: true
    };
    this.datastoreUrl = 'dataStore/metabase/repositories';
  }

  loadRepositories(): Observable<any> {
    return Observable.create(observer => {
      this.http.get(this.datastoreUrl)
        .catch(error => Observable.throw(new Error(error)))
        .subscribe((repositories: any[]) => {
          if(repositories.length > 0) {
            observer.next(repositories);
            observer.complete();
          } else {
            this.updateRepositories([this.defaultRepository])
              .subscribe(updateResponse => {
                observer.next([this.defaultRepository]);
                observer.complete();
              }, editError => {
                observer.error(editError);
              });
          }
        }, error => {
          this.addRepositories([this.defaultRepository])
            .subscribe(addResponse => {
              observer.next([this.defaultRepository]);
              observer.complete();
            }, addError => {
              observer.error(addError);
            });
        })
    })
  }

  updateRepositories(repositoriesData): Observable<any> {
    return this.http.put(this.datastoreUrl, repositoriesData)
      .map(res => {return repositoriesData})
      .catch(error => Observable.throw(new Error(error)));
  }

  addRepositories(repositoriesData): Observable<any> {
    return this.http.post(this.datastoreUrl, repositoriesData)
      .catch(error => Observable.throw(new Error(error)));
  }

  getUrlArray(repositories: any[]): Observable<any>{
    if(repositories.length == 0) {
      return Observable.of([]);
    }

    return Observable.of(repositories.map(repository => {return repository.url}));
  }

}
