import { Component, OnInit } from '@angular/core';
import {ApplicationState} from "../store/application-state";
import {Store} from "@ngrx/store";
import {Observable} from "rxjs";
import {repositoriesSelector} from "../store/selectors/repositories.selector";
import {UpdateRepositoriesAction, LoadMetadataPackagesAction} from "../store/actions";
import {metadataPackagesSelector} from "../store/selectors/metadata-packages.selector";
import {repositoriesUrlArraySelector} from "../store/selectors/repository-url-array.selector";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  repositories$: Observable<any>;
  metadataPackages$: Observable<any>;
  constructor(private store: Store<ApplicationState>) {
    this.repositories$ = store.select(repositoriesSelector);
    this.metadataPackages$ = store.select(metadataPackagesSelector);
  }

  ngOnInit() {

  }

  updateRepositories(repositories) {
    this.store.dispatch(new UpdateRepositoriesAction(repositories));
  }

}
