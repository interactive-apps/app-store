import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-metadata-package',
  templateUrl: './metadata-package.component.html',
  styleUrls: ['./metadata-package.component.css']
})
export class MetadataPackageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
